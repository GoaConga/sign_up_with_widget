import 'package:flutter/material.dart';
import 'package:sign_it_in/home_screen.dart';
import 'package:sign_it_in/trial3/main3.dart';
import 'package:sign_it_in/guide/guide_homescreen.dart';
import 'package:sign_it_in/radio.dart';

class Nav extends StatefulWidget {
  @override
  _NavState createState() => _NavState();
}

class _NavState extends State<Nav> {
  int _selectedIndex = 0;

  void _onItemTap(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
      length: 4,
      child: Scaffold(
          appBar: AppBar(
            title: Text('Bottom Navigation Bar Tutorial'),
            leading: IconButton(icon: Icon(Icons.menu), onPressed: () {}),
            actions: [
              IconButton(
                icon: Icon(Icons.notifications_none),
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(Icons.search),
                onPressed: () {},
              ),
            ],
            flexibleSpace: Container(
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                colors: [Colors.red, Colors.purple],
                begin: Alignment.bottomRight,
                end: Alignment.topLeft,
              )),
            ),
            bottom: TabBar(indicatorColor: Colors.yellow, indicatorWeight: 5,
                //isScrollable: true,
                tabs: [
                  Tab(icon: Icon(Icons.home), text: 'Home'),
                  Tab(icon: Icon(Icons.star), text: 'Feed'),
                  Tab(icon: Icon(Icons.face), text: 'Profile'),
                  Tab(icon: Icon(Icons.settings), text: 'Settings'),
                ]),
            backgroundColor: Colors.orange,
            elevation: 20,
            titleSpacing: 20,
          ),
          body: TabBarView(children: [
            Home(),
            Page2(),
            MyStatefulWidget(),
            buildPage('Setting Page'),
          ])));

  Widget buildPage(String text) => Center(
        child: Text(
          text,
          style: TextStyle(fontSize: 28),
        ),
      );
}
